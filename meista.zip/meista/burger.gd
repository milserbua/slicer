extends Node3D

@export var coin_reward := 200

var sliced := false
var shop_manager

func _ready():
	add_to_group("sliceable")
	shop_manager = get_tree().get_first_node_in_group("shop_manager")

func slice(multiplier := 1.0):
	if sliced:
		return

	sliced = true

	if shop_manager:
		shop_manager.add_coins(int(coin_reward * multiplier))

	var tween = create_tween()
	tween.parallel().tween_property(self, "scale", Vector3.ZERO, 0.2)
	tween.parallel().tween_property(self, "position:y", position.y + 0.4, 0.2)

	await tween.finished

	queue_free()
